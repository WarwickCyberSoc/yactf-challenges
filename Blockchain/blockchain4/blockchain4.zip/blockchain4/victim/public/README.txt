Files needed to interact with the contract (may take a while to generate):
    "abi.json":
        Contains the contract's Application Binary Interface.
    "transaction_reciept.json":
        Contains the reciept of the contract's deployment.
        "contractAddress" gives the contract's address.
