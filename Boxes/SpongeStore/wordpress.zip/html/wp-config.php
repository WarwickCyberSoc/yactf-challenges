<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'wordpress' );

/** MySQL database password */
define( 'DB_PASSWORD', 'C8AzLSKhbf&nkCDy' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '0L@uCUCqL_I-.O]?`!D@2dQ8xQH/dnve;b 4~o/iFvl$n@sPPelM8s`D#u>IW;d^' );
define( 'SECURE_AUTH_KEY',  'h.N-:gA#wjS#l9n9+$G(*_sOTSCk`VOpckrnyJ.7F[42P,OjrN,{5^!Wh8&E-=&w' );
define( 'LOGGED_IN_KEY',    '3[);(Jp9d#MQWAfB,h#q@lTPR:e}?)f7HE]U3pv@6R*<bS@}2rXtk/Xk4DVw1VDB' );
define( 'NONCE_KEY',        '&f:Dot/pma0Umf^m3ze^/+i2-p)K_kmm6=E470&<{W=GYTw9SbIIz:}6Pt`j_hVx' );
define( 'AUTH_SALT',        'ioG,RsHxi4BYhi4ZF.&Cpn6ZZwdxZK>8C)IiiEF  ~YO`s[+PiggbE<fXq %a#dF' );
define( 'SECURE_AUTH_SALT', 'JNJ!K:<)r^WMld3?d&0fj-VANowat~@ao1O<K)L`^.UL(D9uH5/RDchJ:AkM*5Z7' );
define( 'LOGGED_IN_SALT',   ';G)l& IngtCE*h@|X<oA=^B?c Znv6Cw5F3p-Pu2swiz:4WZyi5|o7X`OsFii%a:' );
define( 'NONCE_SALT',       'B>hKa[KOgFm}+UqJ5Rh?}97JV,sint,.%v&Qsk[g55,w !3r;VXP,1z}eu|H3M7X' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';

